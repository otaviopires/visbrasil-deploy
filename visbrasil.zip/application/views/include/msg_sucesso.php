<div class="alert alert-success">
	<?= $msg; ?>
</div>