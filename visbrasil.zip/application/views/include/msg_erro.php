<div class="alert alert-danger">
	<?= $msg; ?>
</div>