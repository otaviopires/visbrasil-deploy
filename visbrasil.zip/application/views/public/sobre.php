<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<!-- Começa o Main -->
<main class="mdl-grid">
    <div class="mdl-cell mdl-cell--6-col">
        <div class="welcome-section">
            <div class="">
                <h4 class="welcome-title">Bem vindo a VISBRASIL</h4>
                <p>Somos uma ong que tem como missão difundir informações sobre saúde no Brasil</p> 
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Aperiam dolore earum assumenda ipsum, dignissimos aut obcaecati praesentium dicta repudiandae libero pariatur, et minus asperiores. Adipisci optio qui labore mollitia aut?</p>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus explicabo quis molestiae nihil? Est consequuntur dolorem sunt dicta nobis, perferendis tempore at facilis accusantium sint possimus deserunt vel culpa error?</p>
            </div>

        </div>
    </div>
    <div class="mdl-cell mdl-cell--6-col">
        <div class="mdl-cell mdl-cell--12-col ">
            <div class="publicidade-sobre-section publicidade-sobre">
                Publicidade 1
            </div>
        </div>
    </div>
</main>

<!-- Fim do Main -->
</div>
<!-- Fim da div que fica no header -->


<!-- JS-->
<script src="https://code.jquery.com/jquery-1.12.3.js"></script>
<script defer src="https://code.getmdl.io/1.1.3/material.min.js"></script>


</body>

</html>