jQuery(function($){
   $("#dataSancao").mask("99/99/9999");
});