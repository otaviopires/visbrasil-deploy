# visbrasil
Projeto VisBrasil

Tecnologia utilizadas:
O Front-end do projeto foi criado utilizando o framework Material Design Lite na versão 1.1.3, podendo ser utilizado pelo seguinte arquivo online: "https://code.getmdl.io/1.1.3/material.indigo-pink.min.css". O plugin jquery utilizado foi o Data Table, responsável pela paginação, ordenação e pesquisa, o qual pode ser encontrado no site "https://datatables.net/examples/styling/material.html".
No Back-end foi utilizado framework CodeIgniter na versão 3.1.0 encontrado no site "https://www.codeigniter.com/", juntamente com o banco de dados MySql. 

Configuração do banco de dados com o codeigniter:
Definimos no codeigniter algumas configurações iniciais do banco de dados, esse arquivo se chama database.php e pode ser encontrado dentro da pasta config:
aplication/config/database.php
